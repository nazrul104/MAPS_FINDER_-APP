	<div class="col_3">
		<ul class="menu-left">
			<li><a class="profile" href="#"><i class="icon-home-2"></i>Home</a></li>
			<li><a class="settings" href="#"><i class="icon-cog"></i>Category</a></li>
			<li><a class="logout" href="#"><i class="icon-maps"></i>Location List</a></li>
			<li><a class="messages" href="#"><i class="icon-checkin"></i>Markers</a></li>
		</ul>
	</div>